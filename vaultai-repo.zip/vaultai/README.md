# 🔐 VaultAI

A personal file vault web application — a college academic project (Stage ST-1).

VaultAI lets a user sign up, log in, and manage their own set of files in a
clean dashboard: upload, search, and delete file entries. This stage focuses
on the **frontend + a mock backend layer**, deliberately structured so it can
be swapped for a real Express.js + database backend in later stages, without
changing the frontend logic.

## 📸 Dashboard Preview

> Add your dashboard screenshot at `assets/dashboard.png` — it will appear here.

![Dashboard Screenshot](assets/dashboard.png)

## 👥 Team & Work Division

| Member | Role | Responsibility |
|---|---|---|
| **Vishwas** | Backend Logic | `auth.js` (signup/login/session) and the `mockBackend` object in `script.js` — structured to mirror future Express.js routes |
| **Vanshika Rana** | Frontend | HTML structure, CSS styling, and DOM rendering/display functions |
| **Tanya** | Session & UX | Logout flow, toast notifications, user initials/avatar logic, AI section placeholder |

Work split: **60% Vishwas (Backend) : 20% Vanshika (Frontend) : 20% Tanya (Session/UX)**

## 🗂️ Project Structure

```
vaultai/
├── login.html      # Login & signup UI
├── index.html       # Main dashboard UI
├── style.css         # All styling
├── auth.js            # Backend logic: mock auth, session (Vishwas)
├── script.js           # mockBackend + rendering + session/toast (all 3 members)
├── assets/
│   └── dashboard.png    # Dashboard screenshot (add your own)
└── README.md
```

## ⚙️ Tech Stack

- HTML5, CSS3, Vanilla JavaScript (no frameworks)
- `localStorage` / `sessionStorage` as a **mock backend/database**
- Browser File API (reads file metadata only — no file content is uploaded anywhere)

## 🧠 Mock Backend Design (ST-1 Scope)

No real server, database, or cloud storage is used yet. Instead:

- **Users** are stored in `localStorage` under `vaultai_users`.
- **Sessions** are written to `localStorage` (if "Remember me" is checked) or
  `sessionStorage` (if not).
- **Files** are stored per-user in `localStorage` under `vaultai_files_<email>`,
  storing only metadata (name, size, type, upload date) — not actual file bytes.

The `getUsers()` / `saveUsers()` / `setSession()` functions in `auth.js`, and
the `mockBackend` object in `script.js`, are written so their function names
and call patterns map 1:1 to future REST endpoints:

| Mock Function | Future Express Route |
|---|---|
| `getUsers()` | `GET /api/users` |
| `setSession()` | `POST /api/session` |
| `mockBackend.getFiles()` | `GET /api/files` |
| `mockBackend.uploadFile()` | `POST /api/files` |
| `mockBackend.deleteFile()` | `DELETE /api/files/:id` |
| `mockBackend.searchFiles()` | `GET /api/files?query=` |

## ⚠️ Known Limitations (ST-1)

- Passwords are stored in **plaintext** in `localStorage` — acceptable only
  for this academic demo stage. A real backend will hash passwords (bcrypt).
- No real server-side validation, no HTTPS, no actual database.
- File **content** is never read or stored — only metadata, via the browser
  File API.

## 🚀 Running Locally

No build step needed — it's plain HTML/CSS/JS.

1. Clone the repo
2. Open `login.html` in your browser (or use a Live Server extension in VS Code)
3. Sign up, then log in to reach the dashboard

## 🗺️ Roadmap

- **ST-2**: Replace mock backend with a real Express.js API
- **ST-3**: Add a real database (MongoDB/SQL) and cloud file storage
