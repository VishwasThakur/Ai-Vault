/* ============================================================
   auth.js
   Owner: Vishwas (Backend Logic)
   ------------------------------------------------------------
   This file simulates a backend authentication layer using
   localStorage as a mock database. The functions below are
   deliberately structured to mirror future Express.js routes:

     getUsers()   -> GET  /api/users        (fetch all users)
     saveUsers()  -> internal DB write helper
     setSession() -> POST /api/session       (create session)

   In later stages, these will be replaced with real HTTP calls
   to an Express + MongoDB/SQL backend, but the function
   signatures and logic flow will stay the same.
   ============================================================ */

const USERS_KEY = "vaultai_users";
const SESSION_KEY = "vaultai_session";

/**
 * Mock DB READ — simulates GET /api/users
 * Returns array of registered users from localStorage.
 */
function getUsers() {
  const data = localStorage.getItem(USERS_KEY);
  return data ? JSON.parse(data) : [];
}

/**
 * Mock DB WRITE — simulates persisting to a users table.
 */
function saveUsers(users) {
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}

/**
 * Mock session creation — simulates POST /api/session (JWT / cookie issue).
 * Writes to sessionStorage or localStorage depending on "Remember me".
 */
function setSession(user, remember) {
  const sessionData = JSON.stringify({
    name: user.name,
    email: user.email,
    loggedInAt: new Date().toISOString(),
  });

  if (remember) {
    localStorage.setItem(SESSION_KEY, sessionData);
  } else {
    sessionStorage.setItem(SESSION_KEY, sessionData);
  }
}

/**
 * Retrieves the active session, checking both storage types.
 */
function getSession() {
  const local = localStorage.getItem(SESSION_KEY);
  const session = sessionStorage.getItem(SESSION_KEY);
  return local ? JSON.parse(local) : session ? JSON.parse(session) : null;
}

/* ---------------- SIGNUP HANDLER ---------------- */
function handleSignup(event) {
  event.preventDefault();

  const name = document.getElementById("signup-name").value.trim();
  const email = document.getElementById("signup-email").value.trim().toLowerCase();
  const password = document.getElementById("signup-password").value;

  if (!name || !email || !password) {
    showToast("Please fill in all fields.", "error");
    return;
  }

  const users = getUsers();
  const exists = users.some((u) => u.email === email);

  if (exists) {
    showToast("An account with this email already exists.", "error");
    return;
  }

  // NOTE: Passwords stored in plaintext for ST-1 demo purposes only.
  // Real backend (Express) will hash passwords using bcrypt.
  users.push({ name, email, password });
  saveUsers(users);

  showToast("Account created successfully! Please log in.", "success");
  setTimeout(() => {
    document.getElementById("show-login-link")?.click();
  }, 1000);
}

/* ---------------- LOGIN HANDLER ---------------- */
function handleLogin(event) {
  event.preventDefault();

  const email = document.getElementById("login-email").value.trim().toLowerCase();
  const password = document.getElementById("login-password").value;
  const remember = document.getElementById("remember-me")?.checked || false;

  const users = getUsers();
  const matchedUser = users.find(
    (u) => u.email === email && u.password === password
  );

  if (!matchedUser) {
    showToast("Invalid email or password.", "error");
    return;
  }

  setSession(matchedUser, remember);
  showToast("Login successful! Redirecting...", "success");

  setTimeout(() => {
    window.location.href = "index.html";
  }, 800);
}

/* ---------------- ROUTE GUARD ---------------- */
function requireAuth() {
  const session = getSession();
  if (!session) {
    window.location.href = "login.html";
  }
  return session;
}

// Attach listeners once DOM is ready (login.html only)
document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("login-form");
  const signupForm = document.getElementById("signup-form");

  if (loginForm) loginForm.addEventListener("submit", handleLogin);
  if (signupForm) signupForm.addEventListener("submit", handleSignup);
});
