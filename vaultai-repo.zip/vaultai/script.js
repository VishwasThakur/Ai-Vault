/* ============================================================
   script.js
   ------------------------------------------------------------
   Section 1 (lines ~1-60)   : mockBackend  -> Owner: Vishwas
   Section 2 (rendering)     : DOM render   -> Owner: Vanshika Rana
   Section 3 (session/toast) : Session/UX   -> Owner: Tanya
   ============================================================ */

/* ============================================================
   SECTION 1: MOCK BACKEND  (Owner: Vishwas)
   ------------------------------------------------------------
   Simulates a file-storage API. Structured to map directly to
   future Express routes:
     mockBackend.getFiles()    -> GET    /api/files
     mockBackend.uploadFile()  -> POST   /api/files
     mockBackend.deleteFile()  -> DELETE /api/files/:id
     mockBackend.searchFiles() -> GET    /api/files?query=
   ============================================================ */
const mockBackend = {
  _storageKey(email) {
    return `vaultai_files_${email}`;
  },

  getFiles(email) {
    const data = localStorage.getItem(this._storageKey(email));
    return data ? JSON.parse(data) : [];
  },

  uploadFile(email, fileMeta) {
    const files = this.getFiles(email);
    const newFile = {
      id: Date.now().toString(),
      name: fileMeta.name,
      size: fileMeta.size,
      type: fileMeta.type || "unknown",
      uploadedAt: new Date().toISOString(),
    };
    files.push(newFile);
    localStorage.setItem(this._storageKey(email), JSON.stringify(files));
    return newFile;
  },

  deleteFile(email, fileId) {
    let files = this.getFiles(email);
    files = files.filter((f) => f.id !== fileId);
    localStorage.setItem(this._storageKey(email), JSON.stringify(files));
  },

  searchFiles(email, query) {
    const files = this.getFiles(email);
    if (!query) return files;
    return files.filter((f) =>
      f.name.toLowerCase().includes(query.toLowerCase())
    );
  },
};
/* ============================ END SECTION 1 ============================ */


/* ============================================================
   SECTION 2: RENDERING / DISPLAY  (Owner: Vanshika Rana)
   ============================================================ */
function renderFileList(files) {
  const container = document.getElementById("file-list");
  if (!container) return;

  if (files.length === 0) {
    container.innerHTML = `<p class="empty-state">No files yet. Upload something!</p>`;
    return;
  }

  container.innerHTML = files
    .map(
      (f) => `
      <div class="file-card" data-id="${f.id}">
        <div class="file-icon">📄</div>
        <div class="file-info">
          <p class="file-name">${f.name}</p>
          <p class="file-meta">${formatSize(f.size)} • ${formatDate(f.uploadedAt)}</p>
        </div>
        <button class="delete-btn" onclick="onDeleteFile('${f.id}')">✕</button>
      </div>`
    )
    .join("");
}

function formatSize(bytes) {
  if (!bytes) return "0 KB";
  const kb = bytes / 1024;
  return kb > 1024 ? `${(kb / 1024).toFixed(2)} MB` : `${kb.toFixed(1)} KB`;
}

function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}
/* ============================ END SECTION 2 ============================ */


/* ============================================================
   SECTION 3: SESSION / LOGOUT / TOAST / INITIALS  (Owner: Tanya)
   ============================================================ */
function initDashboard() {
  const session = requireAuth(); // from auth.js
  if (!session) return;

  document.getElementById("user-name").textContent = session.name;
  document.getElementById("user-initials").textContent = getInitials(session.name);

  loadAndRenderFiles(session.email);

  document.getElementById("logout-btn")?.addEventListener("click", handleLogout);
  document.getElementById("upload-input")?.addEventListener("change", (e) =>
    onUploadFile(e, session.email)
  );
  document.getElementById("search-input")?.addEventListener("keyup", (e) =>
    onSearch(e, session.email)
  );
}

function getInitials(name) {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

function handleLogout() {
  localStorage.removeItem("vaultai_session");
  sessionStorage.removeItem("vaultai_session");
  showToast("Logged out successfully.", "success");
  setTimeout(() => (window.location.href = "login.html"), 600);
}

function showToast(message, type = "success") {
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  setTimeout(() => toast.classList.add("show"), 10);
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 300);
  }, 2500);
}
/* ============================ END SECTION 3 ============================ */


/* ---------------- Glue functions using mockBackend + render ---------------- */
function loadAndRenderFiles(email) {
  const files = mockBackend.getFiles(email);
  renderFileList(files);
}

function onUploadFile(event, email) {
  const file = event.target.files[0];
  if (!file) return;

  mockBackend.uploadFile(email, {
    name: file.name,
    size: file.size,
    type: file.type,
  });

  showToast(`"${file.name}" uploaded.`, "success");
  loadAndRenderFiles(email);
  event.target.value = "";
}

function onDeleteFile(fileId) {
  const session = getSession();
  if (!session) return;
  mockBackend.deleteFile(session.email, fileId);
  showToast("File deleted.", "success");
  loadAndRenderFiles(session.email);
}

function onSearch(event, email) {
  const query = event.target.value;
  const results = mockBackend.searchFiles(email, query);
  renderFileList(results);
}

/* ---------------- AI Section Placeholder (Owner: Tanya) ---------------- */
function initAISection() {
  const aiBox = document.getElementById("ai-section");
  if (!aiBox) return;
  aiBox.innerHTML = `<p class="ai-placeholder">🤖 AI-powered file insights coming in a future stage.</p>`;
}

document.addEventListener("DOMContentLoaded", () => {
  if (document.getElementById("file-list")) {
    initDashboard();
    initAISection();
  }
});
